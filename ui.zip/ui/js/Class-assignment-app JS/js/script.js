var assList = {
    assignments:[],
    addAssign:function(assignText){
        this.assignments.push({
        assignText:assignText,
        completed:false
    }); },
   
    editAssign:function(position,newAssign){
        this.assignments[position].assignText=newAssign;
    },
    deleteAssign:function(position){
    this.assignments.splice(position,1);
    },
    toggleComplete:function(position){
        var assignment = this.assignments[position];
        assignment.completed=!assignment.completed;
    },
    toggleAll:function(){
        var totalAssigns=this.assignments.length;
        var completeAssings=0;
		this.assignments.forEach(function(assignment){
			if(assignment.completed===true){
               completeAssings++;
            }
		});
        if(completeAssings===totalAssigns){
			this.assignments.forEach(function(assignment){
				assignment.completed=false;
			});
        }else{
			this.assignments.forEach(function(assignment){
				assignment.completed=true;
			});
        }
    }
};


var handlers={
	displayAssign:function(){
		view.displayAssign();
},
	toggleAll:function(){
    assList.toggleAll();
	view.displayAssign();
},
	addAssign:function(e){
		if (e.keyCode == 13) {
		var assignTxtInput=document.getElementById('assignTxtInput');
		assList.addAssign(assignTxtInput.value);
		assignTxtInput.value='';
		view.displayAssign();
		}
	},
	editAssign:function(){
		var position=document.getElementById('assignLocationEditInput').valueAsNumber;
		var newAssign=document.getElementById('assignTxtEditInput').value;
		assList.editAssign(position,newAssign);
		assignLocationEditInput.value='';
		assignTxtEditInput.value='';
		view.displayAssign();
	},
	deleteAssign:function(position){
		assList.deleteAssign(position);
		view.displayAssign();
	},
	toggleComplete:function(position){
		assList.toggleComplete(position);
		view.displayAssign();
	}
	
};
var itemLeftCount=0;
var view={
	displayAssign:function(){	
	var assignUl=document.querySelector('ul');
		assignUl.innerHTML='';
	var alreadyCounted=itemLeftCount;
		assList.assignments.forEach(function(assignment,position){
			var checkbox;
			
			var assignLi=document.createElement('li');
			if(assignment.completed===true){
				checkbox=this.createCheckbox();
				checkbox.checked=true;
				assignLi.textContent=assignment.assignText;
			}else{
				itemLeftCount++;
				checkbox=this.createCheckbox();
				checkbox.checked=false;
			assignLi.textContent=assignment.assignText;
			}
			assignLi.id=position;
			assignLi.appendChild(checkbox);
			assignLi.appendChild(this.createDeleteButton());
			assignUl.appendChild(assignLi);
			var strong=document.querySelector('strong');
			strong.textContent=itemLeftCount-alreadyCounted;
		},this);
},
	createDeleteButton:function(){
		var DeleteAssignButton;
		DeleteAssignButton=document.createElement('button');
		DeleteAssignButton.textContent="X";
		DeleteAssignButton.className='deleteAssignButton';
		return DeleteAssignButton;
	},
	createCheckbox:function(){
		var assignCheckbox;
		assignCheckbox=document.createElement('INPUT');
		assignCheckbox.setAttribute("type","checkbox");
		assignCheckbox.className='assignCheckbox';
		return assignCheckbox;
	},
	setUpEventListener:function(){
		var assignUl=document.querySelector('ul');
	assignUl.addEventListener('click',function(event){
	console.log(event.target.parentNode.id);
	var deleteAssignButton=event.target;
	var assignChechbox=event.target;
	if(deleteAssignButton.className==='deleteAssignButton'){
	   handlers.deleteAssign(parseInt(event.target.parentNode.id));
		}
	if(assignChechbox.className==='assignCheckbox'){
		handlers.toggleComplete(parseInt(event.target.parentNode.id))
	}
	})
	}
	
};
	view.setUpEventListener();	
