var assList = {
    assignments:[],
    addAssign:function(assignText){
        this.assignments.push({
        assignText:assignText,
        completed:false
    }); },
   
    editAssign:function(position,newAssign){
        this.assignments[position].assignText=newAssign;
    },
    deleteAssign:function(position){
    this.assignments.splice(position,1);
    },
    toggleComplete:function(position){
        var assignment = this.assignments[position];
        assignment.completed=!assignment.completed;
    },
    toggleAll:function(){
        var totalAssigns=this.assignments.length;
        var completeAssings=0;
        for(var i=0;i<this.assignments.length;i++){
            if(this.assignments[i].completed===true){
               completeAssings++;
            }
        }
        if(completeAssings===totalAssigns){
           for(var i=0;i<totalAssigns;i++){
               this.assignments[i].completed=false;
            }
        }else{
           for(var j=0;j<totalAssigns;j++){
               this.assignments[j].completed=true;
            } 
        }
    }
};


var handlers={
	displayAssign:function(){
		view.displayAssign();
},
	toggleAll:function(){
    assList.toggleAll();
	view.displayAssign();
},
	addAssign:function(){
		var assignTxtInput=document.getElementById('assignTxtInput');
		assList.addAssign(assignTxtInput.value);
		assignTxtInput.value='';
		view.displayAssign();
	},
	editAssign:function(){
		var position=document.getElementById('assignLocationEditInput').valueAsNumber;
		var newAssign=document.getElementById('assignTxtEditInput').value;
		assList.editAssign(position,newAssign);
		assignLocationEditInput.value='';
		assignTxtEditInput.value='';
		view.displayAssign();
	},
	deleteAssign:function(){
		var position=document.getElementById('assignLocationDeleteInput');
		assList.deleteAssign(position);
		assignLocationDeleteInput.value='';
		view.displayAssign();
	},
	toggleComplete:function(){
		var position=document.getElementById('assignLocationToggleCompleteInput');
		assList.toggleComplete(position.valueAsNumber);
		assignLocationToggleCompleteInput.value='';
	view.displayAssign();
	}
	
};

var view={
	displayAssign:function(){	
	var assignUl=document.querySelector('ul');
		assignUl.innerHTML='';
	if(assList.assignments.length===0){
		var errorLi=document.createElement('li');
		errorLi.textContent='There is no item to show!';
		assignUl.appendChild(errorLi);
    }else{
	for(var i=0; i<assList.assignments.length;i++){
		var assign=assList.assignments[i];
		var assignLi=document.createElement('li');
		if(assign.completed===true){
		assignLi.textContent='(X) '+assign.assignText;
		}else{
		assignLi.textContent='( ) '+assign.assignText;
		}
		assignUl.appendChild(assignLi);
	}
	}
}
};