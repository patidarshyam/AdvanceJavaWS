package com.yash.registrationpoc.service;

import java.util.List;

import com.yash.registrationpoc.model.User;

/**
 * This is the service layer of the application which provide the services
 * related to user such as addUser and List user
 * 
 * @author shyam.patidar
 *
 */
public interface UserService {

	/**
	 * This will add the user into database
	 * 
	 * @param user
	 *            Object of user
	 */
	public void addUser(User user);

	/**
	 * This will list the user
	 */
	public List<User> getAllUser();

	/**
	 * This method will check the registrationId is already present or not. If
	 * registrationId already present then return true else false
	 * 
	 * @param registrationId
	 * @return true if registrationId already exist in the database else false
	 */
	public boolean checkRegistrationId(String registrationId);

}
