var validate = {

	/*
	 * Name validation
	 */
	nameValidator : function() {

		event.preventDefault();
		var letters = /^[_A-Z_a-z_ ]*$/;
		var name = document.forms["registerationForm"]["name"].value;
		var namespan = document.getElementById("namespan");

		/* name validation */
		if (name.match(letters)) {
			if (name.length < 5 || 20 < name.length) {
				namespan.innerText = "Name field must contain atleast 5 letters and atmost 20 letters";
				document.registerationForm.name.focus();
				return false;
			}else
				namespan.innerText = "";
		} else if(!name.match(letters)) {
			namespan.innerText = "Please enter alphabet characters only";
			document.registerationForm.name.focus();
			return false;
		}else
			namespan.innerText = "";
		

	},

	/*
	 * validation for contact
	 */
	contactValidator : function() {
		var numbers = /^[0-9]+$/;
		var contact = document.forms["registerationForm"]["contact"].value;
		var contactspan = document.getElementById("contactspan");

		/* contact validation */
		if (contact.match(numbers)) {
			namespan.innerText = "";
			if (contact.length != 10) {
				contactspan.innerText = "Contact should be of 10 digit numebers";
				document.registerationForm.contact.focus();
				return false;
			}
		} else if (!contact.match(numbers)){
			contactspan.innerText = "Please enter valid contact number";
			document.registerationForm.contact.focus();
			return false;
		}else
			contactspan.innerText = "";
		
	},

	/*
	 * validation for email
	 */
	emailValidator : function() {
		var email = document.forms["registerationForm"]["email"].value;
		var atPosition = email.indexOf("@");
		var dotPosition = email.lastIndexOf(".");
		var dotStr = email.substring(atPosition + 1, atPosition + 2);
		var emailspan = document.getElementById("emailspan");

		/* email validation
		 * /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)
		 * 
		 * /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/
		 *  */

		if (atPosition < 1 || dotPosition < (atPosition + 2)
				|| (dotPosition + 2) >= email.length || dotStr == "."
				|| email.indexOf(' ') >= 0) {
			contactspan.innerText = "";
			emailspan.innerText = "Enter proper e-mail address";
			document.registerationForm.email.focus();
			return false;
		}else
			emailspan.innerText = "";
	},

	/*
	 * check for unique registrationId
	 */
	regValidator : function(value) {
		event.preventDefault();
		/*
		 * AJAX call to UserRegistrationIdCheckController for checking the registrationId already present or not.
		 */
		$
				.ajax({
					type : "GET",
					url : "http://localhost:8080/RegistrationPoc/UserRegistrationIdCheckController",
					data : {
						'search_keyword' : value
					},
					dataType : "text",
					success : function(msg) {
						var span = document.getElementById("regIdspan");
						if (msg == "true") {
							/*
							 * Disabled the button if registrationId already present.
							 */
							document.getElementById("registerBtn").disabled = true;
							span.innerText = "RegistrationId already exist. Try again!";
						} else {
							document.getElementById("registerBtn").disabled = false;
							span.innerText = "";
						}
						document.registerationForm.registrationId.focus();
					}
				});
		return;
	},

};
