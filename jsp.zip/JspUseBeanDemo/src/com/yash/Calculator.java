package com.yash;

public class Calculator {
	private String a="a.......";
	public String getA() {
		return a;
	}
	public void setA(String a) {
		this.a = a;
	}
	public int cube(int m){
		return m*m*m;
	}
}
