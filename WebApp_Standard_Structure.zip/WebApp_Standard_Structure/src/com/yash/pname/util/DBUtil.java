package com.yash.pname.util;
import java.sql.*;
/**
 * This class will perform operation related to DB like connection, disconnect, providing
 * preparedStatement object and ResultSet object. This class will be responsible to have
 * transaction complete operation as well like closing connection, PreparedStatement object etc.
 * @author shyam.patidar
 *
 */
public class DBUtil {
	private static String driverClassName="com.mysql.jdbc.Driver";
	private static String url="jdbc:mysql://localhost/cms";
	private static String user="root";
	private static String pwd="root";
	private static Connection con=null;
	public static PreparedStatement pstmt= null;
	/**
	 * Driver Should be loaded whenever DBUtil is called
	 */
	static{
		try {
			Class.forName(driverClassName);	
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}
	//3. Create connection Object
	public static Connection connect(){
		try {
			con = DriverManager.getConnection(url,user,pwd);
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return con;
	}
	/**
	 * This method will return the PreparedStatement object based on the sql provided.
	 * This method should have call for connection because when you need transaction, that time
	 * you will require connection object.
	 * @param sql is any dml query
	 * @return
	 */
	public static PreparedStatement createPreparedstatement(String sql){
		connect();
		try {
			con.prepareStatement(sql);
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return pstmt;
	}
	/**
	 * This is closing the Connection object
	 */
	public static void closeConnection(){
		try {
			con.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	/**
	 * This is closing the PreparedStatement object
	 */
	public static void closePreparedStatement(){
		try {
			pstmt.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
}
