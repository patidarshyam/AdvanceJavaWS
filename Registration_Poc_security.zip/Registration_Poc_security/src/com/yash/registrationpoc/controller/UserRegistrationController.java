package com.yash.registrationpoc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.registrationpoc.exception.RegistrationIdAlreadyExistException;
import com.yash.registrationpoc.model.User;
import com.yash.registrationpoc.service.UserService;
import com.yash.registrationpoc.serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class UserListController
 * 
 * This Controller will handle the registration request and register the user
 * 
 * @author shyam.patidar
 */
@WebServlet("/UserRegistrationController")
public class UserRegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserService userService = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserRegistrationController() {
		super();
		userService = new UserServiceImpl();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 * 
	 *      This method of Controller will handle the registration request and register
	 *      the user.
	 * @throws RegistrationIdAlreadyExistException
	 *             if the registrationId is already exist in the database and
	 *             rediect to registration page again with error message
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		User user = new User();
		user.setName(request.getParameter("name"));
		user.setContact(request.getParameter("contact"));
		user.setEmail(request.getParameter("email"));
		user.setRegistrationId(request.getParameter("registrationId"));
		user.setPassword(request.getParameter("password"));
		
		try {
			userService.addUser(user);
		} catch (RegistrationIdAlreadyExistException e) {
			String message = "This Registration Id Already Exist. Please insert Unique Registration id";
			request.getRequestDispatcher("registration.jsp?err=" + message).forward(request, response);
		}
		request.setAttribute("msg", "Registration done! RegistrationId is your User Name");
		request.getRequestDispatcher("/WEB-INF/view/login.jsp").forward(request, response);
		
	}

}
