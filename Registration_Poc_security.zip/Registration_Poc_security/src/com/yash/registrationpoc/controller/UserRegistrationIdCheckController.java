package com.yash.registrationpoc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.registrationpoc.service.UserService;
import com.yash.registrationpoc.serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class UserRegistrationIdCheckController
 */
@WebServlet("/UserRegistrationIdCheckController")
public class UserRegistrationIdCheckController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private UserService userService; 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserRegistrationIdCheckController() {
        super();
       userService=new UserServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean result= userService.checkRegistrationId(request.getParameter("search_keyword"));
		if(result){
			response.setContentType("text/html");
			response.getWriter().write("true");
		}else
			response.getWriter().write("false");
	}

}
