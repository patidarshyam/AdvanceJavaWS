package com.yash.registrationpoc.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginController
 */
@WebServlet({ "/login" })
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginController() {
		super();
		
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("login controller................");
	
		String error = request.getParameter("error");
		String logout = request.getParameter("logout");
	
		if (error != null) {
			error = "Invalid username and password!";
			request.setAttribute("error", error);
		}
		if (logout != null) {
			String msg = "You've been logged out successfully.";
			request.setAttribute("msg", msg);
		}
		
		getServletContext().getRequestDispatcher("/WEB-INF/view/login.jsp" ).forward(request, response);

	}

}
