package com.yash.registrationpoc.serviceimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.yash.regisrtationpoc.util.DBUtil;
import com.yash.registrationpoc.dao.UserDAO;
import com.yash.registrationpoc.daoimpl.UserDAOImpl;
import com.yash.registrationpoc.model.User;
import com.yash.registrationpoc.service.UserService;

/**
 * This is the implementation class of UserService which provides implementation
 * to the methods addUser() and listUser()
 * 
 * @author shyam.patidar
 *
 */
public class UserServiceImpl implements UserService {

	/**
	 * Reference variable of UserDAO
	 */
	private UserDAO userDAO;

	/**
	 * This constructor will initialize the userServicImpl object
	 */
	public UserServiceImpl() {
		userDAO = new UserDAOImpl();
	}

	/**
	 * This method will add the user
	 */
	@Override
	public void addUser(User user) {
		userDAO.insert(user);
	}

	/**
	 * This will give the list of user
	 * 
	 * @return list of user
	 */
	@Override
	public List<User> getAllUser() {
		return userDAO.list();
	}

	public boolean checkRegistrationId(String registrationId) {
		PreparedStatement preparedStatement = null;
		boolean result = false;
		try {
			preparedStatement = DBUtil.createPreparedstatement("SELECT * FROM users WHERE registrationId=?");
			preparedStatement.setString(1, registrationId);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				result = true;
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closePreparedStatement();
			DBUtil.closeConnection();
		}
	
		return result;
	}
}
