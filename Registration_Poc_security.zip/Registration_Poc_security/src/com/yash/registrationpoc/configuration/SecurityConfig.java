package com.yash.registrationpoc.configuration;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	
	@Autowired
	public void configAuthentication(AuthenticationManagerBuilder auth) throws Exception {
		System.out.println("config query..............");
		DataSource dataSource=dataSource();
		auth.jdbcAuthentication().dataSource(dataSource)
			.usersByUsernameQuery("select username,password, enabled from users where username=?")
			.authoritiesByUsernameQuery("select username, userRole from user_roles where username=?");
	
	}	
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		System.out.println("config role check..............");
		
		http.authorizeRequests()
			.antMatchers("/welcome").access("hasRole('ADMIN')")
			.antMatchers("/js/**","/register").permitAll()
			
			//.antMatchers("/*").authenticated()
			//.antMatchers("/hello/**").access("hasRole('ROLE_ADMIN')") //allow only admin to access hello page
			.and()
				.formLogin().loginPage("/login").failureUrl("/login?error")
					.usernameParameter("username").passwordParameter("password")
					.defaultSuccessUrl("/welcome")
			.and()
				.logout().logoutSuccessUrl("/login?logout")
			.and()
				.exceptionHandling()
			.and()
				.csrf();
			
	}
	
	/*@Override
	public void configure(WebSecurity web) throws Exception {
		System.out.println("config role check..............");
		
		web.ignoring().antMatchers("/js/**");
		
	}*/
	public DriverManagerDataSource dataSource() {
		System.out.println("app config datasource...........");
	    DriverManagerDataSource driverManagerDataSource = new DriverManagerDataSource();
	    driverManagerDataSource.setDriverClassName("com.mysql.jdbc.Driver");
	    driverManagerDataSource.setUrl("jdbc:mysql://localhost:3306/poc");
	    driverManagerDataSource.setUsername("root");
	    driverManagerDataSource.setPassword("root");
	    return driverManagerDataSource;
	}
}