package com.yash.registrationpoc.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//import org.apache.log4j.Logger;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;
import com.yash.regisrtationpoc.util.DBUtil;
import com.yash.registrationpoc.dao.UserDAO;
import com.yash.registrationpoc.exception.RegistrationIdAlreadyExistException;
import com.yash.registrationpoc.model.User;

/**
 * This is the implementation class of UserDAO where the implementation of
 * methods is present. here we perform database related operations.
 * 
 * @author shyam.patidar
 *
 */
public class UserDAOImpl implements UserDAO {
	/**
	 * This is the variable for logger
	 */
	// private static Logger logger = Logger.getLogger(DBUtil.class);

	/**
	 * This method insert the user into database with parameters as
	 * name,contact,email and registerationId
	 * 
	 * @param user
	 *            object of user which we want to insert
	 * 
	 * @throws MySQLIntegrityConstraintViolationException
	 *             if the registrationId is already exist in the database
	 * 
	 * @throws SQLException
	 *             if some sql related exception occur
	 */
	@Override
	public void insert(User user) {

		PreparedStatement preparedStatement = null;
		String sql = "INSERT INTO users(name,contact,email,registrationId,username,password,enabled)VALUES(?,?,?,?,?,?,?)";
		preparedStatement = DBUtil.createPreparedstatement(sql);
		try {
			preparedStatement.setString(1, user.getName());
			preparedStatement.setString(2, user.getContact());
			preparedStatement.setString(3, user.getEmail());
			preparedStatement.setString(4, user.getRegistrationId());
			preparedStatement.setString(5, user.getRegistrationId());
			preparedStatement.setString(6, user.getPassword());
			preparedStatement.setInt(7, 1); // by default active user
			preparedStatement.execute();
			addRole(user.getRegistrationId());
			// logger.info("Data inserted SucessFully!!!");
		} catch (MySQLIntegrityConstraintViolationException ex) {
			throw new RegistrationIdAlreadyExistException("This Registration Id Already Exist.");
		} catch (SQLException e) {
			e.printStackTrace();
			// logger.info("Error :" + e.getMessage());
		} finally {
			DBUtil.closePreparedStatement();
			DBUtil.closeConnection();
		}
	}

	/**
	 * This method will insert the role of the user with username in User Role
	 * table. by default set user role as ROLE_USER
	 * @param userName
	 * 				This is unique for each registered user
	 * 
	 */
	public void addRole(String userName){
		PreparedStatement preparedStatement = null;
		String sql = "INSERT INTO user_roles(username,userRole)VALUES(?,?)";
		preparedStatement = DBUtil.createPreparedstatement(sql);
		try {
			preparedStatement.setString(1, userName);
			preparedStatement.setString(2, "ROLE_USER");
			preparedStatement.execute();
			// logger.info("Data inserted SucessFully!!!");
		} catch (MySQLIntegrityConstraintViolationException ex) {
			throw new RegistrationIdAlreadyExistException("This ROLE is alreay exist with this username.");
		} catch (SQLException e) {
			e.printStackTrace();
			// logger.info("Error :" + e.getMessage());
		} finally {
			DBUtil.closePreparedStatement();
			DBUtil.closeConnection();
		}
	}

	/**
	 * This method will help you to get the list of all registered user from the
	 * database
	 * 
	 * @return List of User
	 * 
	 * @throws SQLException
	 *             if some sql related exception occur
	 */
	@Override
	public List<User> list() {

		PreparedStatement preparedStatement = null;

		List<User> users = new ArrayList<>();

		try {
			String sql = "SELECT * FROM users";
			preparedStatement = DBUtil.createPreparedstatement(sql);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setContact(rs.getString("contact"));
				user.setEmail(rs.getString("email"));
				user.setRegistrationId(rs.getString("registrationId"));
				users.add(user);
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
			// logger.info("Error :" + e.getMessage());
		} finally {
			DBUtil.closePreparedStatement();
			DBUtil.closeConnection();
		}

		return users;
	}

}
